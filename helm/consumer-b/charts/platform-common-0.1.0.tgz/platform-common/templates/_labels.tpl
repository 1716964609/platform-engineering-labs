{{- define "platform-common.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
platform.example.com/standard: "true"
{{- end -}}
